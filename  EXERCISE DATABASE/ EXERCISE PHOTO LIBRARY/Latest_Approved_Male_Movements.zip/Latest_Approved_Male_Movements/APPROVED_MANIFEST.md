# Latest Approved Male Movement Illustrations

This export contains the latest explicitly approved male exercise illustrations produced after the previous approved export.

1. Band-Assisted Front Lever
2. Burpee
3. Hanging Leg Raise
4. L-Sit Hold
5. Nordic Curl
6. Side Plank
7. World's Greatest Stretch
8. Band-Assisted Pull-Up
9. Diamond Push-Up on Kettlebell (#67)
10. High Pull-Up (#74)
11. Hollow Hold — Heels Down (#75)
12. Full Dragon Flag
13. Push-Up on Rings
14. Skin the Cat
15. Tibialis Raise

Only explicitly approved versions are included. Pending corrections and unreviewed movements are excluded.
